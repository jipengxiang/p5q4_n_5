﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace p5q4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private PersonCollection obj;

        private void Form1_Load(object sender, EventArgs e)
        {
            obj = new PersonCollection();
            lblStatus.Text = obj.DbStatus;
            refreshForm();
        }

        private void refreshForm()
        {
            Person p = obj.getCurrentPerson();
            txtName.Text = p.Name;
            txtAge.Text = p.Age + "";
            txtGender.Text = p.Gender + "";
            txtBirthYr.Text = p.getYearOfBirth() + "";
            grpPerson.Text = (obj.Current + 1) + " / " + obj.getTotalNoOfPersons();
        }

        private void btnLast_Click(object sender, EventArgs e)
        {
            obj.Current = obj.getTotalNoOfPersons() - 1;
            refreshForm();
        }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            if (obj.Current > 0)
                obj.Current = obj.Current - 1;

            refreshForm();
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            if (obj.Current < obj.getTotalNoOfPersons() - 1)
                obj.Current = obj.Current + 1;

            refreshForm();
        }

        private void btnFirst_Click(object sender, EventArgs e)
        {
            obj.Current = 0;
            refreshForm();
        }
    }
}
