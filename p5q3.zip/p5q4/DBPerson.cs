﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace p5q4
{
    class DBPerson
    {
        public List<Person> GetPersonList(out string status)
        {
            using (SqlConnection conn = new SqlConnection())
            {
                using (SqlCommand comm = new SqlCommand())
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        using (DataTable table = new DataTable())
                        {
                            DataRow row;
                            status = string.Empty;

                            conn.ConnectionString =
                                "Data Source=DMIT-NB42248-5\\SQLEXPRESS;database=ApplicationDevelopmentDB;integrated security=true";
                            comm.Connection = conn;
                            comm.CommandText = "select tblPerson.name, tblPerson.age, tblGender.genderDesc from tblPerson, tblGender where tblPerson.gender = tblGender.genderId";
                            da.SelectCommand = comm;
                            List<Person> persons = new List<Person>(); //instantiate the persons list

                            try
                            {
                                conn.Open();

                                da.Fill(table);

                           
                                for (int i = 0; i < table.Rows.Count; i++)
                                {
                                    row = table.Rows[i];
                                    
                                    persons.Add(new Person(row["name"].ToString(), int.Parse(row["age"].ToString()), row["genderDesc"].ToString()[0]));
                                    status = string.Empty;

                                }
                            }
                            catch (Exception ex)
                            {
                                status = ex.Message;
                            }
                            finally
                            {
                                conn.Close();
                            }
                            return persons;

                        }
                    }
                }
            }
        }

    }
}
